# frozen_string_literal: true

module Jekyll
  VERSION = "4.0.0.pre.alpha1"
end
