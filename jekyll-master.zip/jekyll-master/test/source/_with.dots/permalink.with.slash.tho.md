---
permalink: /with.dots/permalink.with.slash.tho/
---

I'm a file with dots BUT I have a permalink which ends with a slash.
